package contacto.ylang.generador;

import contacto.comun.cuartetas.GeneradorCuartetas;
import contacto.comun.cuartetas.acceso.IndiceLugar;
import contacto.comun.cuartetas.acceso.LiteralLugar;
import contacto.comun.cuartetas.acceso.Lugar;
import contacto.comun.cuartetas.acceso.NombreLugar;
import contacto.comun.cuartetas.acceso.CampoLugar;
import contacto.comun.tipos.Tipo;
import contacto.ylang.YLangParserBaseVisitor;
import contacto.ylang.YLangParser.*;
import org.antlr.v4.runtime.tree.ParseTreeProperty;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * Genera cuartetas (C3D) para un archivo .y YA validado por
 * YLangSemanticoListener. Visitor por la misma razon que en Zetariano
 * (control de orden de saltos/etiquetas). Devuelve Lugar en vez de
 * String -- ver comun.cuartetas.acceso.Lugar.
 */
public class YLangGeneradorCuartetas extends YLangParserBaseVisitor<Lugar> {

    private final GeneradorCuartetas gen = new GeneradorCuartetas();
    private final ParseTreeProperty<Tipo> tipos;

    private final Deque<String[]> pilaControlFlujo = new ArrayDeque<>();

    public YLangGeneradorCuartetas(ParseTreeProperty<Tipo> tipos) {
        this.tipos = tipos;
    }

    public GeneradorCuartetas getGenerador() {
        return gen;
    }

    // =====================================================================
    // Programa / funciones
    // =====================================================================

    @Override
    public Lugar visitPrograma(ProgramaContext ctx) {
        visit(ctx.seccionFunciones());
        return null;
    }

    @Override
    public Lugar visitSeccionFunciones(SeccionFuncionesContext ctx) {
        for (FuncionDefContext funcion : ctx.funcionDef()) {
            visit(funcion);
        }
        return null;
    }

    @Override
    public Lugar visitFuncionDef(FuncionDefContext ctx) {
        gen.emitirEtiqueta("inicio_" + ctx.ID().getText());
        for (SentenciaContext sentencia : ctx.sentencia()) {
            visit(sentencia);
        }
        return null;
    }

    // =====================================================================
    // Sentencias
    // =====================================================================

    @Override
    public Lugar visitDeclaracionVariable(DeclaracionVariableContext ctx) {
        if (ctx.expresion() != null) {
            Lugar origen = visit(ctx.expresion());
            gen.emitirAsignacion(new NombreLugar(ctx.ID().getText()), origen);
        }
        return null;
    }

    @Override
    public Lugar visitDeclaracionParaInit(DeclaracionParaInitContext ctx) {
        if (ctx.expresion() != null) {
            Lugar origen = visit(ctx.expresion());
            gen.emitirAsignacion(new NombreLugar(ctx.ID().getText()), origen);
        }
        return null;
    }

    @Override
    public Lugar visitSentenciaExpresion(SentenciaExpresionContext ctx) {
        List<ExpresionContext> expresiones = ctx.expresion();
        if (expresiones.size() < 2) {
            visit(expresiones.get(0));
            return null;
        }
        Lugar destino = visit(expresiones.get(0));
        Lugar origen = visit(expresiones.get(1));
        gen.emitirAsignacion(destino, origen);
        return null;
    }

    @Override
    public Lugar visitSentenciaSi(SentenciaSiContext ctx) {
        List<ExpresionContext> condiciones = ctx.expresion();
        List<BloqueIndentadoContext> cuerpos = ctx.bloqueIndentado();
        String etiquetaFin = gen.nuevaEtiqueta();

        for (int i = 0; i < condiciones.size(); i++) {
            Lugar condicion = visit(condiciones.get(i));
            String etiquetaSiguiente = gen.nuevaEtiqueta();
            gen.emitirSaltoSiFalso(condicion, etiquetaSiguiente);
            visit(cuerpos.get(i));
            gen.emitirSalto(etiquetaFin);
            gen.emitirEtiqueta(etiquetaSiguiente);
        }

        if (cuerpos.size() > condiciones.size()) {
            visit(cuerpos.get(cuerpos.size() - 1));
        }

        gen.emitirEtiqueta(etiquetaFin);
        return null;
    }

    @Override
    public Lugar visitBloqueIndentado(BloqueIndentadoContext ctx) {
        for (SentenciaContext sentencia : ctx.sentencia()) {
            visit(sentencia);
        }
        return null;
    }

    @Override
    public Lugar visitSentenciaMientras(SentenciaMientrasContext ctx) {
        String etiquetaInicio = gen.nuevaEtiqueta();
        String etiquetaFin = gen.nuevaEtiqueta();

        gen.emitirEtiqueta(etiquetaInicio);
        Lugar condicion = visit(ctx.expresion());
        gen.emitirSaltoSiFalso(condicion, etiquetaFin);

        pilaControlFlujo.push(new String[]{etiquetaInicio, etiquetaFin});
        visit(ctx.bloqueIndentado());
        pilaControlFlujo.pop();

        gen.emitirSalto(etiquetaInicio);
        gen.emitirEtiqueta(etiquetaFin);
        return null;
    }

    @Override
    public Lugar visitSentenciaHacerMientras(SentenciaHacerMientrasContext ctx) {
        String etiquetaInicio = gen.nuevaEtiqueta();
        String etiquetaContinua = gen.nuevaEtiqueta();
        String etiquetaFin = gen.nuevaEtiqueta();

        gen.emitirEtiqueta(etiquetaInicio);

        pilaControlFlujo.push(new String[]{etiquetaContinua, etiquetaFin});
        visit(ctx.bloqueIndentado());
        pilaControlFlujo.pop();

        gen.emitirEtiqueta(etiquetaContinua);
        Lugar condicion = visit(ctx.expresion());
        gen.emitirSaltoSiVerdadero(condicion, etiquetaInicio);
        gen.emitirEtiqueta(etiquetaFin);
        return null;
    }

    @Override
    public Lugar visitSentenciaPara(SentenciaParaContext ctx) {
        visit(ctx.declaracionParaInit());

        String etiquetaInicio = gen.nuevaEtiqueta();
        String etiquetaContinua = gen.nuevaEtiqueta();
        String etiquetaFin = gen.nuevaEtiqueta();

        gen.emitirEtiqueta(etiquetaInicio);
        Lugar condicion = visit(ctx.expresion(0));
        gen.emitirSaltoSiFalso(condicion, etiquetaFin);

        pilaControlFlujo.push(new String[]{etiquetaContinua, etiquetaFin});
        visit(ctx.bloqueIndentado());
        pilaControlFlujo.pop();

        gen.emitirEtiqueta(etiquetaContinua);
        visit(ctx.expresion(1));
        gen.emitirSalto(etiquetaInicio);
        gen.emitirEtiqueta(etiquetaFin);
        return null;
    }

    @Override
    public Lugar visitSentenciaElegir(SentenciaElegirContext ctx) {
        Lugar selector = visit(ctx.expresion());
        String etiquetaFin = gen.nuevaEtiqueta();

        pilaControlFlujo.push(new String[]{etiquetaFin, etiquetaFin});
        for (CasoElegirContext caso : ctx.casoElegir()) {
            String etiquetaSiguiente = gen.nuevaEtiqueta();
            Lugar temp = gen.nuevoTemporal();
            gen.emitirOperacionBinaria(temp, selector, "==", new LiteralLugar(caso.literalCaso().getText()));
            gen.emitirSaltoSiFalso(temp, etiquetaSiguiente);
            visit(caso.bloqueIndentado());
            gen.emitirEtiqueta(etiquetaSiguiente);
        }
        if (ctx.casoSiempre() != null) {
            visit(ctx.casoSiempre().bloqueIndentado());
        }
        pilaControlFlujo.pop();
        gen.emitirEtiqueta(etiquetaFin);
        return null;
    }

    @Override
    public Lugar visitSentenciaRomper(SentenciaRomperContext ctx) {
        if (!pilaControlFlujo.isEmpty()) {
            gen.emitirSalto(pilaControlFlujo.peek()[1]);
        }
        return null;
    }

    @Override
    public Lugar visitSentenciaContinuar(SentenciaContinuarContext ctx) {
        if (!pilaControlFlujo.isEmpty()) {
            gen.emitirSalto(pilaControlFlujo.peek()[0]);
        }
        return null;
    }

    @Override
    public Lugar visitSentenciaRetornar(SentenciaRetornarContext ctx) {
        Lugar valor = (ctx.expresion() != null) ? visit(ctx.expresion()) : null;
        gen.emitirRetorno(valor);
        return null;
    }

    // =====================================================================
    // Expresiones
    // =====================================================================

    @Override
    public Lugar visitExpEntero(ExpEnteroContext ctx) {
        return new LiteralLugar(ctx.getText());
    }

    @Override
    public Lugar visitExpFlotante(ExpFlotanteContext ctx) {
        return new LiteralLugar(ctx.getText());
    }

    @Override
    public Lugar visitExpCaracter(ExpCaracterContext ctx) {
        return new LiteralLugar(ctx.getText());
    }

    @Override
    public Lugar visitExpCadena(ExpCadenaContext ctx) {
        return new LiteralLugar(ctx.getText());
    }

    @Override
    public Lugar visitExpVerdadero(ExpVerdaderoContext ctx) {
        return new LiteralLugar("1");
    }

    @Override
    public Lugar visitExpFalso(ExpFalsoContext ctx) {
        return new LiteralLugar("0");
    }

    @Override
    public Lugar visitExpId(ExpIdContext ctx) {
        return new NombreLugar(ctx.ID().getText());
    }

    @Override
    public Lugar visitExpParentesis(ExpParentesisContext ctx) {
        return visit(ctx.expresion());
    }

    @Override
    public Lugar visitExpUnario(ExpUnarioContext ctx) {
        Lugar operando = visit(ctx.expresion());
        String operador = (ctx.NOT() != null) ? "!" : "-";
        Lugar temp = gen.nuevoTemporal();
        gen.emitirOperacionUnaria(temp, operador, operando);
        return temp;
    }

    @Override
    public Lugar visitExpIncDecPrefijo(ExpIncDecPrefijoContext ctx) {
        Lugar lugar = visit(ctx.expresion());
        String operador = (ctx.PLUSPLUS() != null) ? "+" : "-";
        gen.emitirOperacionBinaria(lugar, lugar, operador, new LiteralLugar("1"));
        return lugar;
    }

    @Override
    public Lugar visitExpIncDecSufijo(ExpIncDecSufijoContext ctx) {
        Lugar lugar = visit(ctx.expresion());
        Lugar temp = gen.nuevoTemporal();
        gen.emitirAsignacion(temp, lugar);
        String operador = (ctx.PLUSPLUS() != null) ? "+" : "-";
        gen.emitirOperacionBinaria(lugar, lugar, operador, new LiteralLugar("1"));
        return temp;
    }

    @Override
    public Lugar visitExpMultiplicativa(ExpMultiplicativaContext ctx) {
        String operador = (ctx.STAR() != null) ? "*" : "/";
        return emitirBinaria(ctx.expresion(0), operador, ctx.expresion(1));
    }

    @Override
    public Lugar visitExpAditiva(ExpAditivaContext ctx) {
        String operador = (ctx.PLUS() != null) ? "+" : "-";
        return emitirBinaria(ctx.expresion(0), operador, ctx.expresion(1));
    }

    @Override
    public Lugar visitExpRelacional(ExpRelacionalContext ctx) {
        String operador = (ctx.LT() != null) ? "<" : ">";
        return emitirBinaria(ctx.expresion(0), operador, ctx.expresion(1));
    }

    @Override
    public Lugar visitExpIgualdad(ExpIgualdadContext ctx) {
        String operador = (ctx.EQ() != null) ? "==" : "!=";
        return emitirBinaria(ctx.expresion(0), operador, ctx.expresion(1));
    }

    @Override
    public Lugar visitExpAnd(ExpAndContext ctx) {
        return emitirBinaria(ctx.expresion(0), "&&", ctx.expresion(1));
    }

    @Override
    public Lugar visitExpOr(ExpOrContext ctx) {
        return emitirBinaria(ctx.expresion(0), "||", ctx.expresion(1));
    }

    private Lugar emitirBinaria(ExpresionContext izq, String operador, ExpresionContext der) {
        Lugar lugarIzq = visit(izq);
        Lugar lugarDer = visit(der);
        Lugar temp = gen.nuevoTemporal();
        gen.emitirOperacionBinaria(temp, lugarIzq, operador, lugarDer);
        return temp;
    }

    @Override
    public Lugar visitExpIndice(ExpIndiceContext ctx) {
        Lugar base = visit(ctx.expresion(0));
        Lugar indice = visit(ctx.expresion(1));
        return new IndiceLugar(base, indice);
    }

    @Override
    public Lugar visitExpAcceso(ExpAccesoContext ctx) {
        Lugar base = visit(ctx.expresion());
        return new CampoLugar(base, ctx.ID().getText());
    }

    @Override
    public Lugar visitExpLlamadaFuncion(ExpLlamadaFuncionContext ctx) {
        List<Lugar> argumentos = new ArrayList<>();
        if (ctx.argumentos() != null) {
            for (ExpresionContext argumento : ctx.argumentos().expresion()) {
                argumentos.add(visit(argumento));
            }
        }
        Lugar temp = gen.nuevoTemporal();
        gen.emitirLlamada(temp, null, ctx.ID().getText(), argumentos);
        return temp;
    }

    @Override
    public Lugar visitExpLiteralCompuesto(ExpLiteralCompuestoContext ctx) {
        // TODO (pendiente, no hoy): emitir asignaciones elemento/campo por campo.
        for (ExpresionContext elemento : ctx.expresion()) {
            visit(elemento);
        }
        return gen.nuevoTemporal();
    }

    @Override
    public Lugar visitExpImprimir(ExpImprimirContext ctx) {
        if (ctx.expresion() != null) {
            Lugar valor = visit(ctx.expresion());
            gen.emitirImprimir(valor, formatoDe(ctx.expresion()), true);
        }
        return null;
    }

    @Override
    public Lugar visitExpLeer(ExpLeerContext ctx) {
        Lugar temp = gen.nuevoTemporal();
        gen.emitirLeer(temp, "%s");
        return temp;
    }

    private String formatoDe(ExpresionContext ctx) {
        Tipo tipo = tipos.get(ctx);
        if (tipo == null) {
            return "%d";
        }
        switch (tipo.getPrimitivo()) {
            case DECIMAL: return "%f";
            case CARACTER: return "%c";
            case CADENA: return "%s";
            default: return "%d";
        }
    }
}
