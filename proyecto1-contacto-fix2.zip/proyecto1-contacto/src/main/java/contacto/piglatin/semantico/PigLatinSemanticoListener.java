package contacto.piglatin.semantico;

import contacto.comun.errores.RecolectorErrores;
import contacto.comun.errores.TipoError;
import contacto.comun.simbolos.RolSimbolo;
import contacto.comun.simbolos.Simbolo;
import contacto.comun.simbolos.TablaSimbolos;
import contacto.comun.tipos.Operador;
import contacto.comun.tipos.TablaTipos;
import contacto.comun.tipos.Tipo;
import contacto.piglatin.PigLatinBaseListener;
import contacto.piglatin.PigLatinParser.*;
import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeProperty;

import java.util.List;

/**
 * Analiza semanticamente un archivo .pig. A diferencia de Y? y
 * Zetariano, Pig Latin YA NO define sus propias estructuras ni
 * funciones -- todo viene de archivos .z/.y importados. Por eso el
 * constructor recibe "simbolosImportados": la lista combinada de todo
 * lo que el orquestador (comun.orquestador) ya compilo de esos
 * archivos. Se pre-cargan en la tabla local para que buscar/declarar
 * funcione igual que en los otros dos lenguajes, sin logica especial.
 *
 * Limitacion conocida: si dos archivos importados definen un
 * metodo/campo con el mismo nombre+aridad, chocan entre si (la tabla
 * es plana). Aceptable para hoy; se resuelve si hace falta con
 * resolucion calificada (Clase.metodo) mas adelante.
 */
public class PigLatinSemanticoListener extends PigLatinBaseListener {

    private final TablaSimbolos tabla = new TablaSimbolos();
    private final RecolectorErrores errores;
    private final ParseTreeProperty<Tipo> tipos = new ParseTreeProperty<>();

    private final String nombreArchivo;
    private int profundidadCiclo;

    public PigLatinSemanticoListener(RecolectorErrores errores, List<Simbolo> simbolosImportados, String nombreArchivo) {
        this.errores = errores;
        this.nombreArchivo = nombreArchivo;
        for (Simbolo importado : simbolosImportados) {
            tabla.declarar(importado); // colisiones se ignoran a proposito (ver limitacion en el javadoc)
        }
    }

    public TablaSimbolos getTabla() {
        return tabla;
    }

    public ParseTreeProperty<Tipo> getTipos() {
        return tipos;
    }

    // =====================================================================
    // Declaraciones (seccion VARIABILES)
    // =====================================================================

    @Override
    public void exitDeclObjeto(DeclObjetoContext ctx) {
        String nombreClase = ctx.ID(1).getText(); // ID(0) es el nombre de la variable, ID(1) la clase
        // No podemos validar el constructor de la clase importada sin
        // saber su aridad exacta aqui (viene de otro lenguaje, Zetariano);
        // se acepta de forma permisiva, igual que Zetariano hace con
        // "new OtraClase(...)".
        declarar(ctx.ID(0).getText(), Tipo.estructura(nombreClase), ctx);
    }

    @Override
    public void exitDeclEstructura(DeclEstructuraContext ctx) {
        declarar(ctx.ID(0).getText(), Tipo.estructura(ctx.ID(1).getText()), ctx);
    }

    @Override
    public void exitDeclBooleana(DeclBooleanaContext ctx) {
        declarar(ctx.ID().getText(), Tipo.booleano(), ctx);
    }

    @Override
    public void exitDeclConValor(DeclConValorContext ctx) {
        Tipo tipo = resolverTipo(ctx.tipo());
        Tipo tipoValor = tipoDe(ctx.expresion());
        if (!TablaTipos.esAsignable(tipo, tipoValor)) {
            error(TablaTipos.mensajeAsignacion(tipo, tipoValor), ctx);
        }
        declarar(ctx.ID().getText(), tipo, ctx);
    }

    @Override
    public void exitDeclSinValor(DeclSinValorContext ctx) {
        declarar(ctx.ID().getText(), resolverTipo(ctx.tipo()), ctx);
    }

    private void declarar(String nombre, Tipo tipo, ParserRuleContext nodo) {
        Simbolo simbolo = new Simbolo(nombre, tipo, RolSimbolo.VARIABLE, linea(nodo), columna(nodo));
        if (!tabla.declarar(simbolo)) {
            error("'" + nombre + "' ya fue declarado", nodo);
        }
    }

    @Override
    public void exitArregloTipado(ArregloTipadoContext ctx) {
        Tipo tipoElemento = resolverTipo(ctx.tipo());
        declarar(ctx.ID().getText(), Tipo.arregloDe(tipoElemento), ctx);
    }

    @Override
    public void exitArregloInferido(ArregloInferidoContext ctx) {
        // Sin tipo explicito: se infiere de los valores, si hay; si no,
        // se marca error (no se puede saber el tipo de un arreglo vacio
        // sin tipo declarado).
        Tipo tipoElemento = Tipo.error();
        List<ValorListaContext> valores = ctx.listaValores().valorLista();
        if (!valores.isEmpty() && valores.get(0).expresion() != null) {
            tipoElemento = tipoDe(valores.get(0).expresion());
        }
        declarar(ctx.ID().getText(), Tipo.arregloDe(tipoElemento), ctx);
    }

    // =====================================================================
    // Instrucciones
    // =====================================================================

    @Override
    public void exitAsignacionSimple(AsignacionSimpleContext ctx) {
        Tipo tipoDestino = tipoDe(ctx.objetivo());
        Tipo tipoValor = tipoDe(ctx.expresion());
        if (!TablaTipos.esAsignable(tipoDestino, tipoValor)) {
            error(TablaTipos.mensajeAsignacion(tipoDestino, tipoValor), ctx);
        }
    }

    @Override
    public void exitIncremento(IncrementoContext ctx) {
        Tipo tipo = tipoDe(ctx.objetivo());
        if (!tipo.esError() && !tipo.esNumerico()) {
            error("++ / -- solo se aplica a valores numericos, no a " + tipo, ctx);
        }
    }

    @Override
    public void exitCondicional(CondicionalContext ctx) {
        verificarCondicion(ctx.expresion());
    }

    @Override
    public void exitRamaAliterSi(RamaAliterSiContext ctx) {
        verificarCondicion(ctx.expresion());
    }

    @Override
    public void enterCicloDum(CicloDumContext ctx) {
        profundidadCiclo++;
    }

    @Override
    public void exitCicloDum(CicloDumContext ctx) {
        profundidadCiclo--;
        verificarCondicion(ctx.expresion());
    }

    @Override
    public void enterCicloFacere(CicloFacereContext ctx) {
        profundidadCiclo++;
    }

    @Override
    public void exitCicloFacere(CicloFacereContext ctx) {
        profundidadCiclo--;
        verificarCondicion(ctx.expresion());
    }

    @Override
    public void enterCicloPer(CicloPerContext ctx) {
        tabla.entrarAmbito("per");
        profundidadCiclo++;
    }

    @Override
    public void exitCicloPer(CicloPerContext ctx) {
        profundidadCiclo--;
        tabla.salirAmbito();
        verificarCondicion(ctx.expresion());
    }

    @Override
    public void exitPerDeclara(PerDeclaraContext ctx) {
        Tipo tipo = resolverTipo(ctx.tipo());
        Tipo tipoValor = tipoDe(ctx.expresion());
        if (!TablaTipos.esAsignable(tipo, tipoValor)) {
            error(TablaTipos.mensajeAsignacion(tipo, tipoValor), ctx);
        }
        declarar(ctx.ID().getText(), tipo, ctx);
    }

    @Override
    public void exitPerAsigna(PerAsignaContext ctx) {
        Tipo tipoDestino = tipoDe(ctx.objetivo());
        Tipo tipoValor = tipoDe(ctx.expresion());
        if (!TablaTipos.esAsignable(tipoDestino, tipoValor)) {
            error(TablaTipos.mensajeAsignacion(tipoDestino, tipoValor), ctx);
        }
    }

    private void verificarCondicion(ExpresionContext ctx) {
        Tipo tipo = tipoDe(ctx);
        if (!TablaTipos.esCondicionValida(tipo)) {
            error("La condicion debe ser de tipo booleano, no " + tipo, ctx);
        }
    }

    @Override
    public void exitPerge(PergeContext ctx) {
        if (profundidadCiclo == 0) {
            error("'perge' solo se puede usar dentro de un ciclo", ctx);
        }
    }

    @Override
    public void exitInterrumpe(InterrumpeContext ctx) {
        if (profundidadCiclo == 0) {
            error("'interrumpe' solo se puede usar dentro de un ciclo", ctx);
        }
    }

    @Override
    public void exitImprimir(ImprimirContext ctx) {
        for (ExpresionContext valor : ctx.expresion()) {
            Tipo tipo = tipoDe(valor);
            if (tipo.esArreglo() || tipo.esEstructura()) {
                error("No se puede imprimir un arreglo o una estructura/objeto completo", valor);
            }
        }
    }

    @Override
    public void exitLeerEnVariable(LeerEnVariableContext ctx) {
        Tipo tipo = tipoDe(ctx.objetivo());
        if (!tipo.esError() && (tipo.esArreglo() || tipo.esEstructura())) {
            error("No se puede leer directamente sobre un arreglo o una estructura/objeto", ctx);
        }
    }

    // =====================================================================
    // objetivo: id.campo[indice].metodo(...) -- regla plana, no recursiva
    // (a diferencia de "expresion" en Y?/Zetariano), asi que su tipo se
    // resuelve iterando sufijoAcceso en orden, no con el patron bottom-up
    // de costumbre.
    // =====================================================================

    @Override
    public void exitObjetivo(ObjetivoContext ctx) {
        String nombreBase = ctx.ID().getText();
        Simbolo simbolo = tabla.buscar(nombreBase);
        Tipo actual;
        if (simbolo == null) {
            error("'" + nombreBase + "' no ha sido declarado ni importado", ctx);
            actual = Tipo.error();
        } else {
            actual = simbolo.getTipo();
        }

        for (SufijoAccesoContext sufijo : ctx.sufijoAcceso()) {
            if (sufijo instanceof SufijoAtributoContext) {
                actual = resolverAtributo(actual, ((SufijoAtributoContext) sufijo).ID().getText(), sufijo);
            } else if (sufijo instanceof SufijoIndiceContext) {
                actual = resolverIndice(actual, ((SufijoIndiceContext) sufijo).expresion(), sufijo);
            } else if (sufijo instanceof SufijoMetodoContext) {
                actual = resolverMetodo(actual, (SufijoMetodoContext) sufijo);
            }
        }

        tipos.put(ctx, actual);
    }

    private Tipo resolverAtributo(Tipo base, String nombre, ParserRuleContext nodo) {
        if (base.esError()) {
            return Tipo.error();
        }
        if (!base.esEstructura()) {
            error("Solo se puede acceder con '.' a un campo de un objeto/estructura", nodo);
            return Tipo.error();
        }
        // El campo puede venir de una estructura (.y, campos planos en la
        // tabla del propio .y importado -- no tenemos su definicion
        // exacta aqui) o de una clase (.z, campo registrado con su nombre
        // tal cual). Buscamos por nombre plano: aceptable porque cada
        // import trae sus propios simbolos con nombres unicos en la
        // practica (ver limitacion en el javadoc de la clase).
        Simbolo campo = tabla.buscarTipoDefinido(nombre);
        if (campo == null || campo.getRol() != RolSimbolo.VARIABLE) {
            error("No existe el campo/atributo '" + nombre + "' en " + base, nodo);
            return Tipo.error();
        }
        return campo.getTipo();
    }

    private Tipo resolverIndice(Tipo base, ExpresionContext indiceCtx, ParserRuleContext nodo) {
        Tipo indice = tipoDe(indiceCtx);
        if (!indice.esError() && !indice.esNumerico()) {
            error("El indice de un arreglo debe ser numerico, no " + indice, indiceCtx);
        }
        if (base.esError()) {
            return Tipo.error();
        }
        if (!base.esArreglo()) {
            error("No es un arreglo, no se puede indexar", nodo);
            return Tipo.error();
        }
        return base.tipoElemento();
    }

    private Tipo resolverMetodo(Tipo base, SufijoMetodoContext ctx) {
        String nombre = ctx.ID().getText();
        int aridad = (ctx.listaArgumentos() != null) ? ctx.listaArgumentos().expresion().size() : 0;
        if (base.esError()) {
            return Tipo.error();
        }
        if (!base.esEstructura()) {
            error("Solo se puede llamar un metodo sobre un objeto", ctx);
            return Tipo.error();
        }
        Simbolo metodo = tabla.buscarTipoDefinido(nombre + "#" + aridad);
        if (metodo == null) {
            error("No existe el metodo '" + nombre + "' con " + aridad + " argumento(s) en " + base, ctx);
            return Tipo.error();
        }
        return metodo.getTipo();
    }

    @Override
    public void exitExprAcceso(ExprAccesoContext ctx) {
        tipos.put(ctx, tipoDe(ctx.objetivo()));
    }

    // =====================================================================
    // Expresiones
    // =====================================================================

    @Override
    public void exitLitEntero(LitEnteroContext ctx) {
        tipos.put(ctx, Tipo.entero());
    }

    @Override
    public void exitLitDecimal(LitDecimalContext ctx) {
        tipos.put(ctx, Tipo.decimal());
    }

    @Override
    public void exitLitCadena(LitCadenaContext ctx) {
        tipos.put(ctx, Tipo.cadena());
    }

    @Override
    public void exitLitCaracter(LitCaracterContext ctx) {
        tipos.put(ctx, Tipo.caracter());
    }

    @Override
    public void exitLitVerum(LitVerumContext ctx) {
        tipos.put(ctx, Tipo.booleano());
    }

    @Override
    public void exitLitFalsus(LitFalsusContext ctx) {
        tipos.put(ctx, Tipo.booleano());
    }

    @Override
    public void exitExprLiteral(ExprLiteralContext ctx) {
        tipos.put(ctx, tipoDe(ctx.literal()));
    }

    @Override
    public void exitExprAgrupada(ExprAgrupadaContext ctx) {
        tipos.put(ctx, tipoDe(ctx.expresion()));
    }

    @Override
    public void exitExprUnaria(ExprUnariaContext ctx) {
        Tipo operando = tipoDe(ctx.expresion());
        Operador operador = (ctx.NON() != null) ? Operador.NEGACION_LOGICA : Operador.MENOS_UNARIO;
        Tipo resultado = TablaTipos.resultadoUnario(operador, operando);
        if (resultado.esError() && !operando.esError()) {
            error(TablaTipos.mensajeUnario(operador, operando), ctx);
        }
        tipos.put(ctx, resultado);
    }

    @Override
    public void exitExprMulDiv(ExprMulDivContext ctx) {
        Operador operador = (ctx.POR() != null) ? Operador.MULTIPLICACION : Operador.DIVISION;
        resolverBinaria(ctx, ctx.expresion(0), operador, ctx.expresion(1));
    }

    @Override
    public void exitExprSumaResta(ExprSumaRestaContext ctx) {
        Operador operador = (ctx.MAS() != null) ? Operador.SUMA : Operador.RESTA;
        resolverBinaria(ctx, ctx.expresion(0), operador, ctx.expresion(1));
    }

    @Override
    public void exitExprRelacional(ExprRelacionalContext ctx) {
        Operador operador = (ctx.MENOR() != null) ? Operador.MENOR
                : (ctx.MAYOR() != null) ? Operador.MAYOR
                : (ctx.MENORIGUAL() != null) ? Operador.MENOR_IGUAL : Operador.MAYOR_IGUAL;
        resolverBinaria(ctx, ctx.expresion(0), operador, ctx.expresion(1));
    }

    @Override
    public void exitExprIgualdad(ExprIgualdadContext ctx) {
        Operador operador = (ctx.IGUALIGUAL() != null) ? Operador.IGUAL : Operador.DIFERENTE;
        resolverBinaria(ctx, ctx.expresion(0), operador, ctx.expresion(1));
    }

    @Override
    public void exitExprAnd(ExprAndContext ctx) {
        resolverBinaria(ctx, ctx.expresion(0), Operador.AND, ctx.expresion(1));
    }

    @Override
    public void exitExprOr(ExprOrContext ctx) {
        resolverBinaria(ctx, ctx.expresion(0), Operador.OR, ctx.expresion(1));
    }

    private void resolverBinaria(ParserRuleContext nodo, ExpresionContext izq, Operador operador, ExpresionContext der) {
        Tipo tipoIzq = tipoDe(izq);
        Tipo tipoDer = tipoDe(der);
        Tipo resultado = TablaTipos.resultadoBinario(tipoIzq, operador, tipoDer);
        if (resultado.esError() && !tipoIzq.esError() && !tipoDer.esError()) {
            error(TablaTipos.mensajeBinario(tipoIzq, operador, tipoDer), nodo);
        }
        tipos.put(nodo, resultado);
    }

    @Override
    public void exitExprNuevoObjeto(ExprNuevoObjetoContext ctx) {
        // Igual que DeclObjeto: no verificamos el constructor exacto de
        // la clase importada, se acepta de forma permisiva.
        tipos.put(ctx, Tipo.estructura(ctx.ID().getText()));
    }

    @Override
    public void exitExprLlamada(ExprLlamadaContext ctx) {
        String nombre = ctx.llamadaFuncion().ID().getText();
        int aridad = (ctx.llamadaFuncion().listaArgumentos() != null)
                ? ctx.llamadaFuncion().listaArgumentos().expresion().size() : 0;
        Simbolo funcion = tabla.buscarTipoDefinido(nombre + "#" + aridad);
        if (funcion == null) {
            error("No existe la funcion '" + nombre + "' con " + aridad + " argumento(s) (revisa el import)", ctx);
            tipos.put(ctx, Tipo.error());
        } else {
            tipos.put(ctx, funcion.getTipo());
        }
    }

    // =====================================================================
    // Utilidades
    // =====================================================================

    private Tipo resolverTipo(TipoContext ctx) {
        if (ctx instanceof TipoNumerusContext) return Tipo.entero();
        if (ctx instanceof TipoDecimalisContext) return Tipo.decimal();
        if (ctx instanceof TipoTextumContext) return Tipo.cadena();
        if (ctx instanceof TipoLitteraContext) return Tipo.caracter();
        if (ctx instanceof TipoBoolContext) return Tipo.booleano();
        // TipoEstructura: el nombre de una estructura/clase importada
        return Tipo.estructura(ctx.getText());
    }

    private Tipo tipoDe(ParseTree nodo) {
        Tipo tipo = tipos.get(nodo);
        return (tipo != null) ? tipo : Tipo.error();
    }

    private int linea(ParserRuleContext ctx) {
        return ctx.getStart().getLine();
    }

    private int columna(ParserRuleContext ctx) {
        return ctx.getStart().getCharPositionInLine();
    }

    private void error(String mensaje, ParserRuleContext ctx) {
        errores.agregar(TipoError.SEMANTICO, mensaje, linea(ctx), columna(ctx), nombreArchivo);
    }
}
