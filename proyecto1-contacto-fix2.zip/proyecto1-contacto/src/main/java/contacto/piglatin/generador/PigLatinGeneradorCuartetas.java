package contacto.piglatin.generador;

import contacto.comun.cuartetas.GeneradorCuartetas;
import contacto.comun.cuartetas.acceso.CampoLugar;
import contacto.comun.cuartetas.acceso.IndiceLugar;
import contacto.comun.cuartetas.acceso.LiteralLugar;
import contacto.comun.cuartetas.acceso.Lugar;
import contacto.comun.cuartetas.acceso.NombreLugar;
import contacto.comun.tipos.Tipo;
import contacto.piglatin.PigLatinBaseVisitor;
import contacto.piglatin.PigLatinParser.*;
import org.antlr.v4.runtime.tree.ParseTreeProperty;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * Genera cuartetas (C3D) para un archivo .pig YA validado por
 * PigLatinSemanticoListener. Visitor por la misma razon que en los
 * otros dos lenguajes (control de orden de saltos/etiquetas).
 *
 * Diferencia real de forma: "objetivo" (id.campo[i].metodo()) es una
 * lista plana de sufijos, no recursiva -- se resuelve iterando, igual
 * que en el semantico (ver PigLatinSemanticoListener.exitObjetivo).
 *
 * perge = continue (salta a la actualizacion/inicio del ciclo)
 * interrumpe = break (sale del ciclo)
 */
public class PigLatinGeneradorCuartetas extends PigLatinBaseVisitor<Lugar> {

    private final GeneradorCuartetas gen = new GeneradorCuartetas();
    private final ParseTreeProperty<Tipo> tipos;

    // {etiquetaContinua, etiquetaFin} del ciclo mas interno activo
    private final Deque<String[]> pilaControlFlujo = new ArrayDeque<>();

    public PigLatinGeneradorCuartetas(ParseTreeProperty<Tipo> tipos) {
        this.tipos = tipos;
    }

    public GeneradorCuartetas getGenerador() {
        return gen;
    }

    // =====================================================================
    // Programa / secciones
    // =====================================================================

    @Override
    public Lugar visitPrograma(ProgramaContext ctx) {
        if (ctx.seccionVariables() != null) {
            visit(ctx.seccionVariables());
        }
        visit(ctx.seccionMaior());
        return null;
    }

    @Override
    public Lugar visitSeccionVariables(SeccionVariablesContext ctx) {
        for (DeclaracionContext declaracion : ctx.declaracion()) {
            visit(declaracion);
        }
        return null;
    }

    @Override
    public Lugar visitSeccionMaior(SeccionMaiorContext ctx) {
        gen.emitirEtiqueta("inicio_programa");
        for (InstruccionContext instruccion : ctx.instruccion()) {
            visit(instruccion);
        }
        return null;
    }

    // =====================================================================
    // Declaraciones
    // =====================================================================

    @Override
    public Lugar visitDeclObjeto(DeclObjetoContext ctx) {
        List<Lugar> argumentos = evaluarArgumentos(ctx.listaArgumentos());
        gen.emitirLlamada(new NombreLugar(ctx.ID(0).getText()), null, "new_" + ctx.ID(1).getText(), argumentos);
        return null;
    }

    @Override
    public Lugar visitDeclEstructura(DeclEstructuraContext ctx) {
        // TODO (pendiente, no hoy): emitir asignacion campo por campo del
        // literal de estructura. Por ahora solo evaluamos los valores
        // (por sus posibles efectos) sin asignarlos.
        visitLiteralEstructuraParaEfectos(ctx.literalEstructura());
        return null;
    }

    @Override
    public Lugar visitDeclBooleana(DeclBooleanaContext ctx) {
        Lugar valor = (ctx.expresion() != null)
                ? visit(ctx.expresion())
                : new LiteralLugar(ctx.valorBooleano().VERUM() != null ? "1" : "0");
        gen.emitirAsignacion(new NombreLugar(ctx.ID().getText()), valor);
        return null;
    }

    @Override
    public Lugar visitDeclConValor(DeclConValorContext ctx) {
        Lugar valor = visit(ctx.expresion());
        gen.emitirAsignacion(new NombreLugar(ctx.ID().getText()), valor);
        return null;
    }

    @Override
    public Lugar visitDeclSinValor(DeclSinValorContext ctx) {
        return null; // sin valor inicial, nada que emitir
    }

    @Override
    public Lugar visitArregloTipado(ArregloTipadoContext ctx) {
        if (ctx.listaValores() != null) {
            visitListaValoresParaEfectos(ctx.listaValores());
        }
        return null; // TODO: igual que en Zetariano/Y?, falta la asignacion elemento por elemento
    }

    @Override
    public Lugar visitArregloInferido(ArregloInferidoContext ctx) {
        visitListaValoresParaEfectos(ctx.listaValores());
        return null;
    }

    private void visitListaValoresParaEfectos(ListaValoresContext ctx) {
        for (ValorListaContext valor : ctx.valorLista()) {
            if (valor.expresion() != null) {
                visit(valor.expresion());
            } else if (valor.literalEstructura() != null) {
                visitLiteralEstructuraParaEfectos(valor.literalEstructura());
            }
        }
    }

    private void visitLiteralEstructuraParaEfectos(LiteralEstructuraContext ctx) {
        for (AsignacionAtributoContext atributo : ctx.asignacionAtributo()) {
            ValorAtributoContext valor = atributo.valorAtributo();
            if (valor.expresion() != null) {
                visit(valor.expresion());
            } else if (valor.literalEstructura() != null) {
                visitLiteralEstructuraParaEfectos(valor.literalEstructura());
            } else if (valor.listaValores() != null) {
                visitListaValoresParaEfectos(valor.listaValores());
            }
        }
    }

    // =====================================================================
    // Instrucciones
    // =====================================================================

    @Override
    public Lugar visitAsignacionSimple(AsignacionSimpleContext ctx) {
        Lugar destino = visit(ctx.objetivo());
        Lugar origen = visit(ctx.expresion());
        gen.emitirAsignacion(destino, origen);
        return null;
    }

    @Override
    public Lugar visitAsignacionEstructura(AsignacionEstructuraContext ctx) {
        visitLiteralEstructuraParaEfectos(ctx.literalEstructura());
        return null; // TODO: idem visitDeclEstructura
    }

    @Override
    public Lugar visitAsignacionLista(AsignacionListaContext ctx) {
        visitListaValoresParaEfectos(ctx.listaValores());
        return null; // TODO: idem arreglos
    }

    @Override
    public Lugar visitIncremento(IncrementoContext ctx) {
        Lugar lugar = visit(ctx.objetivo());
        String operador = (ctx.MASMAS() != null) ? "+" : "-";
        gen.emitirOperacionBinaria(lugar, lugar, operador, new LiteralLugar("1"));
        return null;
    }

    @Override
    public Lugar visitLlamadaFuncionInstruccion(LlamadaFuncionInstruccionContext ctx) {
        visit(ctx.llamadaFuncion());
        return null;
    }

    @Override
    public Lugar visitLlamadaMetodoInstruccion(LlamadaMetodoInstruccionContext ctx) {
        visit(ctx.objetivo());
        return null;
    }

    @Override
    public Lugar visitCondicional(CondicionalContext ctx) {
        String etiquetaFin = gen.nuevaEtiqueta();
        String etiquetaSiguiente = gen.nuevaEtiqueta();

        Lugar condicion = visit(ctx.expresion());
        gen.emitirSaltoSiFalso(condicion, etiquetaSiguiente);
        visit(ctx.bloque());
        gen.emitirSalto(etiquetaFin);
        gen.emitirEtiqueta(etiquetaSiguiente);

        for (RamaAliterSiContext rama : ctx.ramaAliterSi()) {
            etiquetaSiguiente = gen.nuevaEtiqueta();
            Lugar cond = visit(rama.expresion());
            gen.emitirSaltoSiFalso(cond, etiquetaSiguiente);
            visit(rama.bloque());
            gen.emitirSalto(etiquetaFin);
            gen.emitirEtiqueta(etiquetaSiguiente);
        }

        if (ctx.ramaAliter() != null) {
            visit(ctx.ramaAliter().bloque());
        }

        gen.emitirEtiqueta(etiquetaFin);
        return null;
    }

    @Override
    public Lugar visitBloque(BloqueContext ctx) {
        for (InstruccionContext instruccion : ctx.instruccion()) {
            visit(instruccion);
        }
        return null;
    }

    @Override
    public Lugar visitCicloDum(CicloDumContext ctx) {
        String etiquetaInicio = gen.nuevaEtiqueta();
        String etiquetaFin = gen.nuevaEtiqueta();

        gen.emitirEtiqueta(etiquetaInicio);
        Lugar condicion = visit(ctx.expresion());
        gen.emitirSaltoSiFalso(condicion, etiquetaFin);

        pilaControlFlujo.push(new String[]{etiquetaInicio, etiquetaFin});
        visit(ctx.bloque());
        pilaControlFlujo.pop();

        gen.emitirSalto(etiquetaInicio);
        gen.emitirEtiqueta(etiquetaFin);
        return null;
    }

    @Override
    public Lugar visitCicloFacere(CicloFacereContext ctx) {
        String etiquetaInicio = gen.nuevaEtiqueta();
        String etiquetaContinua = gen.nuevaEtiqueta();
        String etiquetaFin = gen.nuevaEtiqueta();

        gen.emitirEtiqueta(etiquetaInicio);

        pilaControlFlujo.push(new String[]{etiquetaContinua, etiquetaFin});
        visit(ctx.bloque());
        pilaControlFlujo.pop();

        gen.emitirEtiqueta(etiquetaContinua);
        Lugar condicion = visit(ctx.expresion());
        gen.emitirSaltoSiVerdadero(condicion, etiquetaInicio);
        gen.emitirEtiqueta(etiquetaFin);
        return null;
    }

    @Override
    public Lugar visitCicloPer(CicloPerContext ctx) {
        visit(ctx.inicializacionPer());

        String etiquetaInicio = gen.nuevaEtiqueta();
        String etiquetaContinua = gen.nuevaEtiqueta();
        String etiquetaFin = gen.nuevaEtiqueta();

        gen.emitirEtiqueta(etiquetaInicio);
        Lugar condicion = visit(ctx.expresion());
        gen.emitirSaltoSiFalso(condicion, etiquetaFin);

        pilaControlFlujo.push(new String[]{etiquetaContinua, etiquetaFin});
        visit(ctx.bloque());
        pilaControlFlujo.pop();

        gen.emitirEtiqueta(etiquetaContinua);
        visit(ctx.actualizacionPer());
        gen.emitirSalto(etiquetaInicio);
        gen.emitirEtiqueta(etiquetaFin);
        return null;
    }

    @Override
    public Lugar visitPerDeclara(PerDeclaraContext ctx) {
        Lugar valor = visit(ctx.expresion());
        gen.emitirAsignacion(new NombreLugar(ctx.ID().getText()), valor);
        return null;
    }

    @Override
    public Lugar visitPerAsigna(PerAsignaContext ctx) {
        Lugar destino = visit(ctx.objetivo());
        Lugar valor = visit(ctx.expresion());
        gen.emitirAsignacion(destino, valor);
        return null;
    }

    @Override
    public Lugar visitPerIncremento(PerIncrementoContext ctx) {
        Lugar lugar = visit(ctx.objetivo());
        String operador = (ctx.MASMAS() != null) ? "+" : "-";
        gen.emitirOperacionBinaria(lugar, lugar, operador, new LiteralLugar("1"));
        return null;
    }

    @Override
    public Lugar visitPerAsignacion(PerAsignacionContext ctx) {
        Lugar destino = visit(ctx.objetivo());
        Lugar valor = visit(ctx.expresion());
        gen.emitirAsignacion(destino, valor);
        return null;
    }

    @Override
    public Lugar visitPerge(PergeContext ctx) {
        // perge = continue
        if (!pilaControlFlujo.isEmpty()) {
            gen.emitirSalto(pilaControlFlujo.peek()[0]);
        }
        return null;
    }

    @Override
    public Lugar visitInterrumpe(InterrumpeContext ctx) {
        // interrumpe = break
        if (!pilaControlFlujo.isEmpty()) {
            gen.emitirSalto(pilaControlFlujo.peek()[1]);
        }
        return null;
    }

    @Override
    public Lugar visitReddere(ReddereContext ctx) {
        Lugar valor = (ctx.expresion() != null) ? visit(ctx.expresion()) : null;
        gen.emitirRetorno(valor);
        return null;
    }

    @Override
    public Lugar visitImprimir(ImprimirContext ctx) {
        for (ExpresionContext expresion : ctx.expresion()) {
            Lugar valor = visit(expresion);
            gen.emitirImprimir(valor, formatoDe(expresion), false); // Pig Latin nunca agrega \n solo
        }
        return null;
    }

    @Override
    public Lugar visitLeerEnVariable(LeerEnVariableContext ctx) {
        Lugar destino = visit(ctx.objetivo());
        gen.emitirLeer(destino, "%s");
        return null;
    }

    @Override
    public Lugar visitLeerDescartado(LeerDescartadoContext ctx) {
        Lugar temp = gen.nuevoTemporal();
        gen.emitirLeer(temp, "%s");
        return null;
    }

    private String formatoDe(ExpresionContext ctx) {
        Tipo tipo = tipos.get(ctx);
        if (tipo == null) {
            return "%d";
        }
        switch (tipo.getPrimitivo()) {
            case DECIMAL: return "%f";
            case CARACTER: return "%c";
            case CADENA: return "%s";
            default: return "%d";
        }
    }

    // =====================================================================
    // objetivo: id.campo[i].metodo() -- lista plana de sufijos
    // =====================================================================

    @Override
    public Lugar visitObjetivo(ObjetivoContext ctx) {
        Lugar actual = new NombreLugar(ctx.ID().getText());
        for (SufijoAccesoContext sufijo : ctx.sufijoAcceso()) {
            if (sufijo instanceof SufijoAtributoContext) {
                actual = new CampoLugar(actual, ((SufijoAtributoContext) sufijo).ID().getText());
            } else if (sufijo instanceof SufijoIndiceContext) {
                Lugar indice = visit(((SufijoIndiceContext) sufijo).expresion());
                actual = new IndiceLugar(actual, indice);
            } else if (sufijo instanceof SufijoMetodoContext) {
                SufijoMetodoContext metodo = (SufijoMetodoContext) sufijo;
                List<Lugar> argumentos = evaluarArgumentos(metodo.listaArgumentos());
                Lugar temp = gen.nuevoTemporal();
                gen.emitirLlamada(temp, actual, metodo.ID().getText(), argumentos);
                actual = temp;
            }
        }
        return actual;
    }

    private List<Lugar> evaluarArgumentos(ListaArgumentosContext ctx) {
        List<Lugar> lugares = new ArrayList<>();
        if (ctx != null) {
            for (ExpresionContext argumento : ctx.expresion()) {
                lugares.add(visit(argumento));
            }
        }
        return lugares;
    }

    // =====================================================================
    // Expresiones
    // =====================================================================

    @Override
    public Lugar visitExprAcceso(ExprAccesoContext ctx) {
        return visit(ctx.objetivo());
    }

    @Override
    public Lugar visitExprLiteral(ExprLiteralContext ctx) {
        return visit(ctx.literal());
    }

    @Override
    public Lugar visitLitEntero(LitEnteroContext ctx) {
        return new LiteralLugar(ctx.getText());
    }

    @Override
    public Lugar visitLitDecimal(LitDecimalContext ctx) {
        return new LiteralLugar(ctx.getText());
    }

    @Override
    public Lugar visitLitCadena(LitCadenaContext ctx) {
        return new LiteralLugar(ctx.getText());
    }

    @Override
    public Lugar visitLitCaracter(LitCaracterContext ctx) {
        return new LiteralLugar(ctx.getText());
    }

    @Override
    public Lugar visitLitVerum(LitVerumContext ctx) {
        return new LiteralLugar("1");
    }

    @Override
    public Lugar visitLitFalsus(LitFalsusContext ctx) {
        return new LiteralLugar("0");
    }

    @Override
    public Lugar visitExprAgrupada(ExprAgrupadaContext ctx) {
        return visit(ctx.expresion());
    }

    @Override
    public Lugar visitExprUnaria(ExprUnariaContext ctx) {
        Lugar operando = visit(ctx.expresion());
        String operador = (ctx.NON() != null) ? "!" : "-";
        Lugar temp = gen.nuevoTemporal();
        gen.emitirOperacionUnaria(temp, operador, operando);
        return temp;
    }

    @Override
    public Lugar visitExprMulDiv(ExprMulDivContext ctx) {
        String operador = (ctx.POR() != null) ? "*" : "/";
        return emitirBinaria(ctx.expresion(0), operador, ctx.expresion(1));
    }

    @Override
    public Lugar visitExprSumaResta(ExprSumaRestaContext ctx) {
        String operador = (ctx.MAS() != null) ? "+" : "-";
        return emitirBinaria(ctx.expresion(0), operador, ctx.expresion(1));
    }

    @Override
    public Lugar visitExprRelacional(ExprRelacionalContext ctx) {
        String operador = (ctx.MENOR() != null) ? "<" : (ctx.MAYOR() != null) ? ">"
                : (ctx.MENORIGUAL() != null) ? "<=" : ">=";
        return emitirBinaria(ctx.expresion(0), operador, ctx.expresion(1));
    }

    @Override
    public Lugar visitExprIgualdad(ExprIgualdadContext ctx) {
        String operador = (ctx.IGUALIGUAL() != null) ? "==" : "!=";
        return emitirBinaria(ctx.expresion(0), operador, ctx.expresion(1));
    }

    @Override
    public Lugar visitExprAnd(ExprAndContext ctx) {
        return emitirBinaria(ctx.expresion(0), "&&", ctx.expresion(1));
    }

    @Override
    public Lugar visitExprOr(ExprOrContext ctx) {
        return emitirBinaria(ctx.expresion(0), "||", ctx.expresion(1));
    }

    private Lugar emitirBinaria(ExpresionContext izq, String operador, ExpresionContext der) {
        Lugar lugarIzq = visit(izq);
        Lugar lugarDer = visit(der);
        Lugar temp = gen.nuevoTemporal();
        gen.emitirOperacionBinaria(temp, lugarIzq, operador, lugarDer);
        return temp;
    }

    @Override
    public Lugar visitExprNuevoObjeto(ExprNuevoObjetoContext ctx) {
        List<Lugar> argumentos = evaluarArgumentos(ctx.listaArgumentos());
        Lugar temp = gen.nuevoTemporal();
        gen.emitirLlamada(temp, null, "new_" + ctx.ID().getText(), argumentos);
        return temp;
    }

    @Override
    public Lugar visitExprLlamada(ExprLlamadaContext ctx) {
        return visit(ctx.llamadaFuncion());
    }

    @Override
    public Lugar visitLlamadaFuncion(LlamadaFuncionContext ctx) {
        List<Lugar> argumentos = evaluarArgumentos(ctx.listaArgumentos());
        Lugar temp = gen.nuevoTemporal();
        gen.emitirLlamada(temp, null, ctx.ID().getText(), argumentos);
        return temp;
    }
}
