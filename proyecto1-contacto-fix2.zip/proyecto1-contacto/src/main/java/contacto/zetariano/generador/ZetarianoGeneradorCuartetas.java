package contacto.zetariano.generador;

import contacto.comun.cuartetas.GeneradorCuartetas;
import contacto.comun.cuartetas.acceso.CampoLugar;
import contacto.comun.cuartetas.acceso.IndiceLugar;
import contacto.comun.cuartetas.acceso.LiteralLugar;
import contacto.comun.cuartetas.acceso.Lugar;
import contacto.comun.cuartetas.acceso.NombreLugar;
import contacto.comun.tipos.Tipo;
import contacto.zetariano.ZetarianoBaseVisitor;
import contacto.zetariano.ZetarianoParser.*;
import org.antlr.v4.runtime.tree.ParseTreeProperty;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * Genera cuartetas (C3D) para un archivo .z YA validado por
 * ZetarianoSemanticoListener. Visitor (no Listener): ver el javadoc
 * completo de la version anterior de esta clase / de
 * YLangGeneradorCuartetas para el porque.
 *
 * Cada visitExpXxx devuelve un Lugar (variable/temporal/literal/campo/
 * indice) en vez de un String plano -- asi cada cuarteta sabe generar
 * su propio C directamente (ver comun.cuartetas.acceso.Lugar).
 */
public class ZetarianoGeneradorCuartetas extends ZetarianoBaseVisitor<Lugar> {

    private final GeneradorCuartetas gen = new GeneradorCuartetas();
    private final ParseTreeProperty<Tipo> tipos;

    private final Deque<String[]> pilaControlFlujo = new ArrayDeque<>();

    public ZetarianoGeneradorCuartetas(ParseTreeProperty<Tipo> tipos) {
        this.tipos = tipos;
    }

    public GeneradorCuartetas getGenerador() {
        return gen;
    }

    // =====================================================================
    // Programa / clase / miembros
    // =====================================================================

    @Override
    public Lugar visitPrograma(ProgramaContext ctx) {
        visit(ctx.clase());
        return null;
    }

    @Override
    public Lugar visitClase(ClaseContext ctx) {
        for (MiembroContext miembro : ctx.miembro()) {
            visit(miembro);
        }
        return null;
    }

    @Override
    public Lugar visitCampo(CampoContext ctx) {
        return null; // se resuelve al generar el constructor en C (manana)
    }

    @Override
    public Lugar visitConstructor(ConstructorContext ctx) {
        gen.emitirEtiqueta("inicio_" + ctx.ID().getText() + "_constructor");
        for (SentenciaContext sentencia : ctx.bloque().sentencia()) {
            visit(sentencia);
        }
        return null;
    }

    @Override
    public Lugar visitMetodo(MetodoContext ctx) {
        gen.emitirEtiqueta("inicio_" + ctx.ID().getText());
        for (SentenciaContext sentencia : ctx.bloque().sentencia()) {
            visit(sentencia);
        }
        return null;
    }

    // =====================================================================
    // Sentencias
    // =====================================================================

    @Override
    public Lugar visitBloque(BloqueContext ctx) {
        for (SentenciaContext sentencia : ctx.sentencia()) {
            visit(sentencia);
        }
        return null;
    }

    @Override
    public Lugar visitDeclaracionVariable(DeclaracionVariableContext ctx) {
        if (ctx.expresion() != null) {
            Lugar origen = visit(ctx.expresion());
            gen.emitirAsignacion(new NombreLugar(ctx.ID().getText()), origen);
        }
        return null;
    }

    @Override
    public Lugar visitSentenciaExpresion(SentenciaExpresionContext ctx) {
        List<ExpresionContext> expresiones = ctx.expresion();
        if (expresiones.size() < 2) {
            visit(expresiones.get(0));
            return null;
        }

        Lugar destino = visit(expresiones.get(0));
        Lugar origen = visit(expresiones.get(1));
        OperadorAsignacionContext op = ctx.operadorAsignacion();

        if (op.ASSIGN() != null) {
            gen.emitirAsignacion(destino, origen);
        } else {
            String operador = (op.PLUS_ASSIGN() != null) ? "+"
                    : (op.MINUS_ASSIGN() != null) ? "-" : "*";
            gen.emitirOperacionBinaria(destino, destino, operador, origen);
        }
        return null;
    }

    @Override
    public Lugar visitSentenciaIf(SentenciaIfContext ctx) {
        List<ExpresionContext> condiciones = ctx.expresion();
        List<SentenciaOBloqueContext> cuerpos = ctx.sentenciaOBloque();
        String etiquetaFin = gen.nuevaEtiqueta();

        for (int i = 0; i < condiciones.size(); i++) {
            Lugar condicion = visit(condiciones.get(i));
            String etiquetaSiguiente = gen.nuevaEtiqueta();
            gen.emitirSaltoSiFalso(condicion, etiquetaSiguiente);
            visit(cuerpos.get(i));
            gen.emitirSalto(etiquetaFin);
            gen.emitirEtiqueta(etiquetaSiguiente);
        }

        if (cuerpos.size() > condiciones.size()) {
            visit(cuerpos.get(cuerpos.size() - 1));
        }

        gen.emitirEtiqueta(etiquetaFin);
        return null;
    }

    @Override
    public Lugar visitSentenciaOBloque(SentenciaOBloqueContext ctx) {
        if (ctx.bloque() != null) {
            visit(ctx.bloque());
        } else {
            visit(ctx.sentencia());
        }
        return null;
    }

    @Override
    public Lugar visitSentenciaWhile(SentenciaWhileContext ctx) {
        String etiquetaInicio = gen.nuevaEtiqueta();
        String etiquetaFin = gen.nuevaEtiqueta();

        gen.emitirEtiqueta(etiquetaInicio);
        Lugar condicion = visit(ctx.expresion());
        gen.emitirSaltoSiFalso(condicion, etiquetaFin);

        pilaControlFlujo.push(new String[]{etiquetaInicio, etiquetaFin});
        visit(ctx.sentenciaOBloque());
        pilaControlFlujo.pop();

        gen.emitirSalto(etiquetaInicio);
        gen.emitirEtiqueta(etiquetaFin);
        return null;
    }

    @Override
    public Lugar visitSentenciaDoWhile(SentenciaDoWhileContext ctx) {
        String etiquetaInicio = gen.nuevaEtiqueta();
        String etiquetaContinua = gen.nuevaEtiqueta();
        String etiquetaFin = gen.nuevaEtiqueta();

        gen.emitirEtiqueta(etiquetaInicio);

        pilaControlFlujo.push(new String[]{etiquetaContinua, etiquetaFin});
        visit(ctx.bloque());
        pilaControlFlujo.pop();

        gen.emitirEtiqueta(etiquetaContinua);
        Lugar condicion = visit(ctx.expresion());
        gen.emitirSaltoSiVerdadero(condicion, etiquetaInicio);
        gen.emitirEtiqueta(etiquetaFin);
        return null;
    }

    @Override
    public Lugar visitSentenciaFor(SentenciaForContext ctx) {
        if (ctx.forInit() != null) {
            visit(ctx.forInit());
        }

        String etiquetaInicio = gen.nuevaEtiqueta();
        String etiquetaContinua = gen.nuevaEtiqueta();
        String etiquetaFin = gen.nuevaEtiqueta();

        gen.emitirEtiqueta(etiquetaInicio);
        if (ctx.expresion() != null) {
            Lugar condicion = visit(ctx.expresion());
            gen.emitirSaltoSiFalso(condicion, etiquetaFin);
        }

        pilaControlFlujo.push(new String[]{etiquetaContinua, etiquetaFin});
        visit(ctx.sentenciaOBloque());
        pilaControlFlujo.pop();

        gen.emitirEtiqueta(etiquetaContinua);
        if (ctx.forUpdate() != null) {
            visit(ctx.forUpdate());
        }
        gen.emitirSalto(etiquetaInicio);
        gen.emitirEtiqueta(etiquetaFin);
        return null;
    }

    @Override
    public Lugar visitForInit(ForInitContext ctx) {
        if (ctx.declaracionVariableSinPuntoYComa() != null) {
            visit(ctx.declaracionVariableSinPuntoYComa());
        } else {
            visit(ctx.expresionLista());
        }
        return null;
    }

    @Override
    public Lugar visitDeclaracionVariableSinPuntoYComa(DeclaracionVariableSinPuntoYComaContext ctx) {
        if (ctx.expresion() != null) {
            Lugar origen = visit(ctx.expresion());
            gen.emitirAsignacion(new NombreLugar(ctx.ID().getText()), origen);
        }
        return null;
    }

    @Override
    public Lugar visitForUpdate(ForUpdateContext ctx) {
        visit(ctx.expresionLista());
        return null;
    }

    @Override
    public Lugar visitExpresionLista(ExpresionListaContext ctx) {
        for (ExpresionContext expresion : ctx.expresion()) {
            visit(expresion);
        }
        return null;
    }

    @Override
    public Lugar visitSentenciaSwitch(SentenciaSwitchContext ctx) {
        Lugar selector = visit(ctx.expresion());
        String etiquetaFin = gen.nuevaEtiqueta();

        pilaControlFlujo.push(new String[]{etiquetaFin, etiquetaFin});
        for (CasoSwitchContext caso : ctx.casoSwitch()) {
            String etiquetaSiguiente = gen.nuevaEtiqueta();
            Lugar temp = gen.nuevoTemporal();
            gen.emitirOperacionBinaria(temp, selector, "==", new LiteralLugar(caso.literalCaso().getText()));
            gen.emitirSaltoSiFalso(temp, etiquetaSiguiente);
            for (SentenciaContext sentencia : caso.sentencia()) {
                visit(sentencia);
            }
            gen.emitirEtiqueta(etiquetaSiguiente);
        }
        if (ctx.casoDefault() != null) {
            for (SentenciaContext sentencia : ctx.casoDefault().sentencia()) {
                visit(sentencia);
            }
        }
        pilaControlFlujo.pop();
        gen.emitirEtiqueta(etiquetaFin);
        return null;
    }

    @Override
    public Lugar visitSentenciaBreak(SentenciaBreakContext ctx) {
        if (!pilaControlFlujo.isEmpty()) {
            gen.emitirSalto(pilaControlFlujo.peek()[1]);
        }
        return null;
    }

    @Override
    public Lugar visitSentenciaContinue(SentenciaContinueContext ctx) {
        if (!pilaControlFlujo.isEmpty()) {
            gen.emitirSalto(pilaControlFlujo.peek()[0]);
        }
        return null;
    }

    @Override
    public Lugar visitSentenciaReturn(SentenciaReturnContext ctx) {
        Lugar valor = (ctx.expresion() != null) ? visit(ctx.expresion()) : null;
        gen.emitirRetorno(valor);
        return null;
    }

    // =====================================================================
    // Expresiones
    // =====================================================================

    @Override
    public Lugar visitExpEntero(ExpEnteroContext ctx) {
        return new LiteralLugar(ctx.getText());
    }

    @Override
    public Lugar visitExpDecimal(ExpDecimalContext ctx) {
        return new LiteralLugar(ctx.getText());
    }

    @Override
    public Lugar visitExpCaracter(ExpCaracterContext ctx) {
        return new LiteralLugar(ctx.getText());
    }

    @Override
    public Lugar visitExpCadena(ExpCadenaContext ctx) {
        return new LiteralLugar(ctx.getText());
    }

    @Override
    public Lugar visitExpVerdadero(ExpVerdaderoContext ctx) {
        return new LiteralLugar("1");
    }

    @Override
    public Lugar visitExpFalso(ExpFalsoContext ctx) {
        return new LiteralLugar("0");
    }

    @Override
    public Lugar visitExpNulo(ExpNuloContext ctx) {
        return new LiteralLugar("NULL");
    }

    @Override
    public Lugar visitExpThis(ExpThisContext ctx) {
        return new NombreLugar("this");
    }

    @Override
    public Lugar visitExpId(ExpIdContext ctx) {
        return new NombreLugar(ctx.ID().getText());
    }

    @Override
    public Lugar visitExpParentesis(ExpParentesisContext ctx) {
        return visit(ctx.expresion());
    }

    @Override
    public Lugar visitExpUnario(ExpUnarioContext ctx) {
        Lugar operando = visit(ctx.expresion());
        String operador = (ctx.NOT() != null) ? "!" : "-";
        Lugar temp = gen.nuevoTemporal();
        gen.emitirOperacionUnaria(temp, operador, operando);
        return temp;
    }

    @Override
    public Lugar visitExpIncDecPrefijo(ExpIncDecPrefijoContext ctx) {
        Lugar lugar = visit(ctx.expresion());
        String operador = (ctx.INC() != null) ? "+" : "-";
        gen.emitirOperacionBinaria(lugar, lugar, operador, new LiteralLugar("1"));
        return lugar;
    }

    @Override
    public Lugar visitExpIncDecSufijo(ExpIncDecSufijoContext ctx) {
        Lugar lugar = visit(ctx.expresion());
        Lugar temp = gen.nuevoTemporal();
        gen.emitirAsignacion(temp, lugar);
        String operador = (ctx.INC() != null) ? "+" : "-";
        gen.emitirOperacionBinaria(lugar, lugar, operador, new LiteralLugar("1"));
        return temp;
    }

    @Override
    public Lugar visitExpMultiplicativa(ExpMultiplicativaContext ctx) {
        String operador = (ctx.STAR() != null) ? "*" : (ctx.SLASH() != null) ? "/" : "%";
        return emitirBinaria(ctx.expresion(0), operador, ctx.expresion(1));
    }

    @Override
    public Lugar visitExpAditiva(ExpAditivaContext ctx) {
        String operador = (ctx.PLUS() != null) ? "+" : "-";
        return emitirBinaria(ctx.expresion(0), operador, ctx.expresion(1));
    }

    @Override
    public Lugar visitExpRelacional(ExpRelacionalContext ctx) {
        String operador = (ctx.LT() != null) ? "<" : (ctx.GT() != null) ? ">"
                : (ctx.LE() != null) ? "<=" : ">=";
        return emitirBinaria(ctx.expresion(0), operador, ctx.expresion(1));
    }

    @Override
    public Lugar visitExpIgualdad(ExpIgualdadContext ctx) {
        String operador = (ctx.EQ() != null) ? "==" : "!=";
        return emitirBinaria(ctx.expresion(0), operador, ctx.expresion(1));
    }

    @Override
    public Lugar visitExpAnd(ExpAndContext ctx) {
        return emitirBinaria(ctx.expresion(0), "&&", ctx.expresion(1));
    }

    @Override
    public Lugar visitExpOr(ExpOrContext ctx) {
        return emitirBinaria(ctx.expresion(0), "||", ctx.expresion(1));
    }

    private Lugar emitirBinaria(ExpresionContext izq, String operador, ExpresionContext der) {
        Lugar lugarIzq = visit(izq);
        Lugar lugarDer = visit(der);
        Lugar temp = gen.nuevoTemporal();
        gen.emitirOperacionBinaria(temp, lugarIzq, operador, lugarDer);
        return temp;
    }

    @Override
    public Lugar visitExpTernario(ExpTernarioContext ctx) {
        Lugar condicion = visit(ctx.expresion(0));
        String etiquetaFalso = gen.nuevaEtiqueta();
        String etiquetaFin = gen.nuevaEtiqueta();
        Lugar temp = gen.nuevoTemporal();

        gen.emitirSaltoSiFalso(condicion, etiquetaFalso);
        gen.emitirAsignacion(temp, visit(ctx.expresion(1)));
        gen.emitirSalto(etiquetaFin);
        gen.emitirEtiqueta(etiquetaFalso);
        gen.emitirAsignacion(temp, visit(ctx.expresion(2)));
        gen.emitirEtiqueta(etiquetaFin);

        return temp;
    }

    @Override
    public Lugar visitExpIndice(ExpIndiceContext ctx) {
        Lugar base = visit(ctx.expresion(0));
        Lugar indice = visit(ctx.expresion(1));
        return new IndiceLugar(base, indice);
    }

    @Override
    public Lugar visitExpAcceso(ExpAccesoContext ctx) {
        Lugar base = visit(ctx.expresion());
        return new CampoLugar(base, ctx.ID().getText());
    }

    @Override
    public Lugar visitExpLlamadaLocal(ExpLlamadaLocalContext ctx) {
        List<Lugar> argumentos = evaluarArgumentos(ctx.argumentos());
        Lugar temp = gen.nuevoTemporal();
        gen.emitirLlamada(temp, new NombreLugar("this"), ctx.ID().getText(), argumentos);
        return temp;
    }

    @Override
    public Lugar visitExpLlamadaMetodo(ExpLlamadaMetodoContext ctx) {
        Lugar objetivo = visit(ctx.expresion());
        List<Lugar> argumentos = evaluarArgumentos(ctx.argumentos());
        Lugar temp = gen.nuevoTemporal();
        gen.emitirLlamada(temp, objetivo, ctx.ID().getText(), argumentos);
        return temp;
    }

    @Override
    public Lugar visitExpNuevoObjeto(ExpNuevoObjetoContext ctx) {
        List<Lugar> argumentos = evaluarArgumentos(ctx.argumentos());
        Lugar temp = gen.nuevoTemporal();
        gen.emitirLlamada(temp, null, "new_" + ctx.ID().getText(), argumentos);
        return temp;
    }

    private List<Lugar> evaluarArgumentos(ArgumentosContext ctx) {
        List<Lugar> lugares = new ArrayList<>();
        if (ctx != null) {
            for (ExpresionContext argumento : ctx.expresion()) {
                lugares.add(visit(argumento));
            }
        }
        return lugares;
    }

    @Override
    public Lugar visitExpNuevoArreglo(ExpNuevoArregloContext ctx) {
        List<Lugar> dimensiones = new ArrayList<>();
        for (ExpresionContext dimension : ctx.expresion()) {
            dimensiones.add(visit(dimension));
        }
        Lugar temp = gen.nuevoTemporal();
        gen.emitirLlamada(temp, null, "new_arreglo_" + ctx.tipoPrimitivo().getText(), dimensiones);
        return temp;
    }

    @Override
    public Lugar visitExpArregloLiteral(ExpArregloLiteralContext ctx) {
        // TODO (pendiente, no hoy): emitir asignaciones elemento por elemento.
        for (ExpresionContext elemento : ctx.expresion()) {
            visit(elemento);
        }
        return gen.nuevoTemporal();
    }

    @Override
    public Lugar visitExpLlamadaPrintln(ExpLlamadaPrintlnContext ctx) {
        if (ctx.expresion() != null) {
            Lugar valor = visit(ctx.expresion());
            gen.emitirImprimir(valor, formatoDe(ctx.expresion()), true);
        }
        return null;
    }

    @Override
    public Lugar visitExpLlamadaPrint(ExpLlamadaPrintContext ctx) {
        if (ctx.expresion() != null) {
            Lugar valor = visit(ctx.expresion());
            gen.emitirImprimir(valor, formatoDe(ctx.expresion()), false);
        }
        return null;
    }

    @Override
    public Lugar visitExpLlamadaReadln(ExpLlamadaReadlnContext ctx) {
        Lugar temp = gen.nuevoTemporal();
        gen.emitirLeer(temp, "%s");
        return temp;
    }

    private String formatoDe(ExpresionContext ctx) {
        Tipo tipo = tipos.get(ctx);
        if (tipo == null) {
            return "%d";
        }
        switch (tipo.getPrimitivo()) {
            case DECIMAL: return "%f";
            case CARACTER: return "%c";
            case CADENA: return "%s";
            default: return "%d";
        }
    }
}
