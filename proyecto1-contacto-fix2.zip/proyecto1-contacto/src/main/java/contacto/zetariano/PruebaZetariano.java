package contacto.zetariano;

import contacto.comun.cuartetas.Cuarteta;
import contacto.comun.codegen.GeneradorCodigoC;
import contacto.comun.errores.ErrorCompilacion;
import contacto.comun.errores.EscuchaErrores;
import contacto.comun.errores.RecolectorErrores;
import contacto.comun.errores.TipoError;
import contacto.zetariano.generador.ZetarianoGeneradorCuartetas;
import contacto.zetariano.semantico.ZetarianoSemanticoListener;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;

import java.io.IOException;
import java.nio.file.Path;

/**
 * Prueba manual de punta a punta para un archivo .z: lexer -> parser ->
 * analisis semantico -> generador de cuartetas. Uso:
 *
 *   java contacto.zetariano.PruebaZetariano ruta/al/archivo.z
 *
 * Si no se le pasa argumento, usa test-programs/pila/Pila.z por defecto.
 */
public class PruebaZetariano {

    public static void main(String[] args) throws IOException {
        String ruta = (args.length > 0) ? args[0] : "test-programs/pila/Pila.z";
        RecolectorErrores errores = new RecolectorErrores();

        CharStream entrada = CharStreams.fromPath(Path.of(ruta));

        ZetarianoLexer lexer = new ZetarianoLexer(entrada);
        lexer.removeErrorListeners();
        lexer.addErrorListener(new EscuchaErrores(errores, TipoError.LEXICO, ruta));

        ZetarianoParser parser = new ZetarianoParser(new CommonTokenStream(lexer));
        parser.removeErrorListeners();
        parser.addErrorListener(new EscuchaErrores(errores, TipoError.SINTACTICO, ruta));

        ParseTree arbol = parser.programa();

        if (errores.tieneErrores()) {
            imprimirErrores(errores);
            return;
        }

        ZetarianoSemanticoListener semantico = new ZetarianoSemanticoListener(errores, ruta);
        ParseTreeWalker.DEFAULT.walk(semantico, arbol);

        if (errores.tieneErrores()) {
            imprimirErrores(errores);
            return;
        }

        System.out.println("Semantico OK, sin errores.\n");

        ZetarianoGeneradorCuartetas generador = new ZetarianoGeneradorCuartetas(semantico.getTipos());
        generador.visit(arbol);

        System.out.println("--- Cuartetas generadas ---");
        for (Cuarteta cuarteta : generador.getGenerador().getCuartetas()) {
            System.out.println(cuarteta);
        }

        String codigoC = GeneradorCodigoC.generar(ruta, semantico.getTabla(), generador.getGenerador());
        java.nio.file.Path salida = Path.of("salida.c");
        java.nio.file.Files.writeString(salida, codigoC);
        System.out.println("\n--- Codigo C escrito en " + salida.toAbsolutePath() + " ---");
    }

    private static void imprimirErrores(RecolectorErrores errores) {
        System.out.println("Se encontraron errores:");
        for (ErrorCompilacion error : errores.getErrores()) {
            System.out.println("  " + error);
        }
        System.exit(1);
    }
}
