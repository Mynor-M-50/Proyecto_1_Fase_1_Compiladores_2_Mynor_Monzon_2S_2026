package contacto.comun.codegen;

import contacto.comun.cuartetas.Cuarteta;
import contacto.comun.cuartetas.GeneradorCuartetas;
import contacto.comun.simbolos.RolSimbolo;
import contacto.comun.simbolos.Simbolo;
import contacto.comun.simbolos.TablaSimbolos;
import contacto.comun.tipos.Tipo;

import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Envuelve una lista de cuartetas ya generadas (cada una sabe emitir su
 * propio C via Cuarteta.generarC, ver comun.cuartetas.CodigoTransformable)
 * en un archivo .c completo y compilable: #include, declaracion de
 * variables/temporales, y el cuerpo dentro de main().
 *
 * Alcance de hoy (documentado a proposito, no es un descuido):
 *  - Genera UN SOLO main() con todas las cuartetas en secuencia. Las
 *    etiquetas "inicio_X" ya delimitan donde empieza cada funcion o
 *    metodo del lenguaje fuente dentro del flujo, pero emitirlas como
 *    funciones C de verdad (con su propio "return" real de C en vez de
 *    goto/etiquetas simuladas) es trabajo para cuando este el
 *    orquestador multi-archivo.
 *  - Los tipos ESTRUCTURA (clases/structs) se declaran como "void*":
 *    compila, pero no reserva ni accede memoria real todavia. Falta
 *    emitir "struct NombreClase { ... };" por cada clase, lo que
 *    necesita la lista de campos de cada .z/.y -- no solo la tabla de
 *    simbolos de UN archivo aislado (de nuevo, tarea del orquestador).
 *  - Todos los temporales se declaran "double" por simplicidad (cubre
 *    entero y decimal sin tener que rastrear el tipo exacto de cada
 *    temporal individualmente).
 */
public final class GeneradorCodigoC {

    private GeneradorCodigoC() {
    }

    public static String generar(String nombrePrograma, TablaSimbolos tabla, GeneradorCuartetas generador) {
        StringBuilder codigo = new StringBuilder();
        codigo.append("// Generado automaticamente a partir de ").append(nombrePrograma).append("\n");
        codigo.append("#include <stdio.h>\n");
        codigo.append("#include <stdlib.h>\n\n");
        codigo.append("int main(void) {\n");

        declararVariables(codigo, tabla);
        declararTemporales(codigo, generador);
        codigo.append('\n');

        for (Cuarteta cuarteta : generador.getCuartetas()) {
            codigo.append("    ");
            cuarteta.generarC(codigo);
        }

        codigo.append("\n    return 0;\n");
        codigo.append("}\n");
        return codigo.toString();
    }

    private static void declararVariables(StringBuilder codigo, TablaSimbolos tabla) {
        Set<String> yaDeclaradas = new LinkedHashSet<>();
        for (Simbolo simbolo : tabla.getHistorial()) {
            if (simbolo.getRol() != RolSimbolo.VARIABLE && simbolo.getRol() != RolSimbolo.PARAMETRO) {
                continue;
            }
            if (!yaDeclaradas.add(simbolo.getNombre())) {
                continue; // mismo nombre repetido en dos ambitos distintos, ver TODO de nombres en GeneradorCuartetas
            }
            codigo.append("    ").append(mapearTipoC(simbolo.getTipo()))
                    .append(' ').append(simbolo.getNombre()).append(";\n");
        }
    }

    private static void declararTemporales(StringBuilder codigo, GeneradorCuartetas generador) {
        int cantidad = generador.getCantidadTemporales();
        if (cantidad == 0) {
            return;
        }
        codigo.append("    double ");
        for (int i = 0; i < cantidad; i++) {
            if (i > 0) {
                codigo.append(", ");
            }
            codigo.append('t').append(i);
        }
        codigo.append("; // temporales (double por simplicidad, ver TODO de la clase)\n");
    }

    /** Traduce un Tipo del compilador a su declaracion equivalente en C. */
    public static String mapearTipoC(Tipo tipo) {
        StringBuilder sb = new StringBuilder(mapearPrimitivoC(tipo));
        for (int i = 0; i < tipo.getProfundidadArreglo(); i++) {
            sb.append('*'); // arreglo -> puntero; la reserva de memoria real es tarea futura
        }
        return sb.toString();
    }

    private static String mapearPrimitivoC(Tipo tipo) {
        if (tipo.esEstructura()) {
            return "void*"; // TODO: "struct " + tipo.getNombreEstructura() + "*" cuando existan las struct en C
        }
        if (tipo.getPrimitivo() == null) {
            return "int";
        }
        switch (tipo.getPrimitivo()) {
            case ENTERO:
                return "int";
            case DECIMAL:
                return "double";
            case CARACTER:
                return "char";
            case CADENA:
                return "char*";
            case BOOLEANO:
                return "int";
            default:
                return "int";
        }
    }
}
