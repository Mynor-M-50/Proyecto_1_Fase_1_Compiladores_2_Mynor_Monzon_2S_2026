package contacto.comun.cuartetas;

import contacto.comun.cuartetas.acceso.Lugar;

/**
 * destino = izquierdo OPERADOR derecho   (binaria)
 * destino = OPERADOR izquierdo           (unaria, derecho == null)
 */
public class OperacionCuarteta extends Cuarteta {

    private final Lugar destino;
    private final Lugar izquierdo;
    private final String operador;
    private final Lugar derecho;

    public OperacionCuarteta(int numero, Lugar destino, Lugar izquierdo, String operador, Lugar derecho) {
        super(numero);
        this.destino = destino;
        this.izquierdo = izquierdo;
        this.operador = operador;
        this.derecho = derecho;
    }

    public Lugar getDestino() {
        return destino;
    }

    public Lugar getIzquierdo() {
        return izquierdo;
    }

    public String getOperador() {
        return operador;
    }

    public Lugar getDerecho() {
        return derecho;
    }

    public boolean esUnaria() {
        return derecho == null;
    }

    @Override
    public void generarC(StringBuilder codigo) {
        destino.generarC(codigo);
        codigo.append(" = ");
        if (esUnaria()) {
            codigo.append(operador);
            izquierdo.generarC(codigo);
        } else {
            izquierdo.generarC(codigo);
            codigo.append(' ').append(operador).append(' ');
            derecho.generarC(codigo);
        }
        codigo.append(";\n");
    }

    @Override
    public String toString() {
        if (esUnaria()) {
            return getNumero() + ": " + destino + " = " + operador + izquierdo;
        }
        return getNumero() + ": " + destino + " = " + izquierdo + " " + operador + " " + derecho;
    }
}
