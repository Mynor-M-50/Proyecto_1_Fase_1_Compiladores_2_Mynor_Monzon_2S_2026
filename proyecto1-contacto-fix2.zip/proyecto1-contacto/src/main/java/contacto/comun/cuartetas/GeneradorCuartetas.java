package contacto.comun.cuartetas;

import contacto.comun.cuartetas.acceso.Lugar;
import contacto.comun.cuartetas.acceso.NombreLugar;

import java.util.ArrayList;
import java.util.List;

/**
 * Helper compartido por el generador de cuartetas de cualquiera de los
 * 3 lenguajes: lleva los contadores de temporales, etiquetas y numero
 * de cuarteta, y ofrece un metodo emitirXxx por cada tipo de cuarteta.
 */
public class GeneradorCuartetas {

    private final List<Cuarteta> cuartetas = new ArrayList<>();
    private int contadorCuartetas = 0;
    private int contadorTemporales = 0;
    private int contadorEtiquetas = 0;

    /** Nuevo temporal como Lugar, listo para usar como destino/operando. */
    public NombreLugar nuevoTemporal() {
        return new NombreLugar("t" + (contadorTemporales++));
    }

    public String nuevaEtiqueta() {
        return "L" + (contadorEtiquetas++);
    }

    public void emitirAsignacion(Lugar destino, Lugar origen) {
        cuartetas.add(new AsignacionCuarteta(contadorCuartetas++, destino, origen));
    }

    public void emitirOperacionBinaria(Lugar destino, Lugar izquierdo, String operador, Lugar derecho) {
        cuartetas.add(new OperacionCuarteta(contadorCuartetas++, destino, izquierdo, operador, derecho));
    }

    public void emitirOperacionUnaria(Lugar destino, String operador, Lugar operando) {
        cuartetas.add(new OperacionCuarteta(contadorCuartetas++, destino, operando, operador, null));
    }

    public void emitirEtiqueta(String nombre) {
        cuartetas.add(new EtiquetaCuarteta(contadorCuartetas++, nombre));
    }

    public void emitirSalto(String etiquetaDestino) {
        cuartetas.add(new SaltoCuarteta(contadorCuartetas++, etiquetaDestino));
    }

    public void emitirSaltoSiFalso(Lugar condicion, String etiquetaDestino) {
        cuartetas.add(new SaltoCondicionalCuarteta(contadorCuartetas++, condicion, true, etiquetaDestino));
    }

    public void emitirSaltoSiVerdadero(Lugar condicion, String etiquetaDestino) {
        cuartetas.add(new SaltoCondicionalCuarteta(contadorCuartetas++, condicion, false, etiquetaDestino));
    }

    public void emitirImprimir(Lugar valor, String formatoC, boolean saltoLinea) {
        cuartetas.add(new ImprimirCuarteta(contadorCuartetas++, valor, formatoC, saltoLinea));
    }

    public void emitirLeer(Lugar destino, String formatoC) {
        cuartetas.add(new LeerCuarteta(contadorCuartetas++, destino, formatoC));
    }

    public void emitirLlamada(Lugar destino, Lugar objetivo, String nombre, List<Lugar> argumentos) {
        cuartetas.add(new LlamadaCuarteta(contadorCuartetas++, destino, objetivo, nombre, argumentos));
    }

    public void emitirRetorno(Lugar valor) {
        cuartetas.add(new RetornoCuarteta(contadorCuartetas++, valor));
    }

    public List<Cuarteta> getCuartetas() {
        return cuartetas;
    }

    public int getCantidadTemporales() {
        return contadorTemporales;
    }
}
