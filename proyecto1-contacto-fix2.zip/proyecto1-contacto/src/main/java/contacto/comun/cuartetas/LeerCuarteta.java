package contacto.comun.cuartetas;

import contacto.comun.cuartetas.acceso.Lugar;

/** scanf(formatoC, &destino); */
public class LeerCuarteta extends Cuarteta {

    private final Lugar destino;
    private final String formatoC;

    public LeerCuarteta(int numero, Lugar destino, String formatoC) {
        super(numero);
        this.destino = destino;
        this.formatoC = formatoC;
    }

    public Lugar getDestino() {
        return destino;
    }

    @Override
    public void generarC(StringBuilder codigo) {
        codigo.append("scanf(\"").append(formatoC).append("\", &");
        destino.generarC(codigo);
        codigo.append(");\n");
    }

    @Override
    public String toString() {
        return getNumero() + ": read " + destino;
    }
}
