package contacto.comun.cuartetas;

import contacto.comun.cuartetas.acceso.Lugar;

import java.util.List;

/**
 * [destino =] nombre(objetivo?, arg1, arg2, ...)
 *
 * "objetivo" es null para una llamada a funcion libre (Y?) o a un
 * constructor (new Clase(...)); "destino" es null cuando no interesa
 * el valor de retorno (una llamada usada como sentencia suelta).
 *
 * TODO (pendiente, no hoy): "nombre" hoy es el nombre de metodo tal
 * cual del lenguaje fuente (p.ej. "apilar"), sin mezclar el nombre de
 * la clase (deberia ser algo como "Pila_apilar" en C, para no chocar
 * con un metodo del mismo nombre en otra clase). Falta decidir la
 * convencion de "name mangling" cuando tengamos el orquestador
 * multi-archivo armado (ahi si sabemos con certeza la clase real de
 * cada objeto, incluso los importados de otro .z).
 */
public class LlamadaCuarteta extends Cuarteta {

    private final Lugar destino;
    private final Lugar objetivo;
    private final String nombre;
    private final List<Lugar> argumentos;

    public LlamadaCuarteta(int numero, Lugar destino, Lugar objetivo, String nombre, List<Lugar> argumentos) {
        super(numero);
        this.destino = destino;
        this.objetivo = objetivo;
        this.nombre = nombre;
        this.argumentos = argumentos;
    }

    public Lugar getDestino() { return destino; }
    public Lugar getObjetivo() { return objetivo; }
    public String getNombre() { return nombre; }
    public List<Lugar> getArgumentos() { return argumentos; }

    @Override
    public void generarC(StringBuilder codigo) {
        if (destino != null) {
            destino.generarC(codigo);
            codigo.append(" = ");
        }
        codigo.append(nombre).append('(');
        boolean primero = true;
        if (objetivo != null) {
            objetivo.generarC(codigo);
            primero = false;
        }
        for (Lugar argumento : argumentos) {
            if (!primero) {
                codigo.append(", ");
            }
            argumento.generarC(codigo);
            primero = false;
        }
        codigo.append(");\n");
    }

    @Override
    public String toString() {
        String llamada = (objetivo != null ? objetivo + "." : "") + nombre
                + "(" + argumentosTexto() + ")";
        return getNumero() + ": " + (destino != null ? destino + " = call " : "call ") + llamada;
    }

    private String argumentosTexto() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < argumentos.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(argumentos.get(i));
        }
        return sb.toString();
    }
}
