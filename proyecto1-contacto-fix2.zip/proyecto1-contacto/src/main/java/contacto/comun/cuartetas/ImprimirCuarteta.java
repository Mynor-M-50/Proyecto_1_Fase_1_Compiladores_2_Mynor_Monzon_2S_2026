package contacto.comun.cuartetas;

import contacto.comun.cuartetas.acceso.Lugar;

/** printf(formatoC, valor);  (+ un "\n" si saltoLinea). */
public class ImprimirCuarteta extends Cuarteta {

    private final Lugar valor;
    private final String formatoC; // "%d", "%f", "%c", "%s"...
    private final boolean saltoLinea;

    public ImprimirCuarteta(int numero, Lugar valor, String formatoC, boolean saltoLinea) {
        super(numero);
        this.valor = valor;
        this.formatoC = formatoC;
        this.saltoLinea = saltoLinea;
    }

    public Lugar getValor() {
        return valor;
    }

    @Override
    public void generarC(StringBuilder codigo) {
        codigo.append("printf(\"").append(formatoC);
        if (saltoLinea) {
            codigo.append("\\n");
        }
        codigo.append("\", ");
        valor.generarC(codigo);
        codigo.append(");\n");
    }

    @Override
    public String toString() {
        return getNumero() + ": print " + valor + (saltoLinea ? " (con salto de linea)" : "");
    }
}
