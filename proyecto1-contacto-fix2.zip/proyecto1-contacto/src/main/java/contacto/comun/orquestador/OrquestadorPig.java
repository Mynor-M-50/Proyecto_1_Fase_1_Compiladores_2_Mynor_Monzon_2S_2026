package contacto.comun.orquestador;

import contacto.comun.codegen.GeneradorCodigoC;
import contacto.comun.cuartetas.GeneradorCuartetas;
import contacto.comun.errores.EscuchaErrores;
import contacto.comun.errores.RecolectorErrores;
import contacto.comun.errores.TipoError;
import contacto.comun.simbolos.Simbolo;
import contacto.comun.simbolos.TablaSimbolos;
import contacto.piglatin.PigLatinLexer;
import contacto.piglatin.PigLatinParser;
import contacto.piglatin.generador.PigLatinGeneradorCuartetas;
import contacto.piglatin.semantico.PigLatinSemanticoListener;
import contacto.ylang.YLangLexer;
import contacto.ylang.YLangParser;
import contacto.ylang.semantico.YLangSemanticoListener;
import contacto.zetariano.ZetarianoLexer;
import contacto.zetariano.ZetarianoParser;
import contacto.zetariano.semantico.ZetarianoSemanticoListener;

import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Compila un archivo .pig JUNTO CON los .z/.y que importa: resuelve
 * cada "import", compila cada archivo con el pipeline de su propio
 * lenguaje, junta sus tablas de simbolos, y con eso compila el .pig.
 * Es la pieza que hace que "import" haga algo real -- antes de esto,
 * cada archivo se analizaba aislado (ver la limitacion documentada en
 * ZetarianoSemanticoListener y YLangSemanticoListener).
 *
 * Cada error trae el nombre del archivo de origen (ver
 * ErrorCompilacion.getArchivo()), necesario porque aqui hay varios
 * archivos compilandose en una sola pasada.
 *
 * Limitaciones de hoy:
 *  - Resuelve rutas de import literal: "utils.utils.y" -> carpeta del
 *    .pig + "utils/utils.y". No hay classpath ni busqueda en varias
 *    carpetas.
 *  - Si cualquier archivo tiene errores, se detiene ahi -- no sigue
 *    compilando el resto para juntar mas errores de una vez.
 *  - El .c final solo trae las cuartetas del .pig. Las de cada .z/.y
 *    importado se generan por separado (no se combinan en un solo
 *    archivo C todavia).
 */
public final class OrquestadorPig {

    public static final class Resultado {
        public final RecolectorErrores errores = new RecolectorErrores();
        public TablaSimbolos tablaPig;
        public GeneradorCuartetas cuartetasPig;
        public String codigoC;
    }

    private OrquestadorPig() {
    }

    public static Resultado compilar(Path archivoPig) throws IOException {
        Resultado resultado = new Resultado();
        String nombrePig = archivoPig.toString();

        CharStream entradaPig = CharStreams.fromPath(archivoPig);
        PigLatinLexer lexerPig = new PigLatinLexer(entradaPig);
        lexerPig.removeErrorListeners();
        lexerPig.addErrorListener(new EscuchaErrores(resultado.errores, TipoError.LEXICO, nombrePig));
        PigLatinParser parserPig = new PigLatinParser(new CommonTokenStream(lexerPig));
        parserPig.removeErrorListeners();
        parserPig.addErrorListener(new EscuchaErrores(resultado.errores, TipoError.SINTACTICO, nombrePig));

        PigLatinParser.ProgramaContext arbolPig = parserPig.programa();
        if (resultado.errores.tieneErrores()) {
            return resultado;
        }

        List<Simbolo> simbolosImportados = new ArrayList<>();
        if (arbolPig.seccionImports() != null) {
            for (PigLatinParser.RutaImportContext ruta : arbolPig.seccionImports().rutaImport()) {
                Path archivoImportado = resolverRuta(archivoPig.getParent(), ruta.getText());
                simbolosImportados.addAll(compilarImportado(archivoImportado, resultado.errores));
                if (resultado.errores.tieneErrores()) {
                    return resultado;
                }
            }
        }

        PigLatinSemanticoListener semantico = new PigLatinSemanticoListener(resultado.errores, simbolosImportados, nombrePig);
        ParseTreeWalker.DEFAULT.walk(semantico, arbolPig);
        if (resultado.errores.tieneErrores()) {
            return resultado;
        }

        PigLatinGeneradorCuartetas generador = new PigLatinGeneradorCuartetas(semantico.getTipos());
        generador.visit(arbolPig);

        resultado.tablaPig = semantico.getTabla();
        resultado.cuartetasPig = generador.getGenerador();
        resultado.codigoC = GeneradorCodigoC.generar(nombrePig, semantico.getTabla(), generador.getGenerador());
        return resultado;
    }

    /** "utils.utils.y" -> carpetaBase/utils/utils.y ; "Nodo.z" -> carpetaBase/Nodo.z */
    private static Path resolverRuta(Path carpetaBase, String rutaImport) {
        int ultimoPunto = rutaImport.lastIndexOf('.');
        String sinExtension = rutaImport.substring(0, ultimoPunto).replace('.', '/');
        String extension = rutaImport.substring(ultimoPunto); // incluye el punto: ".z" o ".y"
        return carpetaBase.resolve(sinExtension + extension);
    }

    private static List<Simbolo> compilarImportado(Path archivo, RecolectorErrores errores) throws IOException {
        String nombre = archivo.getFileName().toString();
        if (nombre.endsWith(".z")) {
            return compilarZetariano(archivo, errores);
        }
        if (nombre.endsWith(".y")) {
            return compilarYLang(archivo, errores);
        }
        errores.agregar(TipoError.SEMANTICO, "No se reconoce la extension del import: " + archivo, 0, 0, archivo.toString());
        return List.of();
    }

    private static List<Simbolo> compilarZetariano(Path archivo, RecolectorErrores errores) throws IOException {
        String nombreArchivo = archivo.toString();
        CharStream entrada = CharStreams.fromPath(archivo);
        ZetarianoLexer lexer = new ZetarianoLexer(entrada);
        lexer.removeErrorListeners();
        lexer.addErrorListener(new EscuchaErrores(errores, TipoError.LEXICO, nombreArchivo));
        ZetarianoParser parser = new ZetarianoParser(new CommonTokenStream(lexer));
        parser.removeErrorListeners();
        parser.addErrorListener(new EscuchaErrores(errores, TipoError.SINTACTICO, nombreArchivo));

        ParseTree arbol = parser.programa();
        if (errores.tieneErrores()) {
            return List.of();
        }

        ZetarianoSemanticoListener semantico = new ZetarianoSemanticoListener(errores, nombreArchivo);
        ParseTreeWalker.DEFAULT.walk(semantico, arbol);
        return semantico.getTabla().getHistorial();
    }

    private static List<Simbolo> compilarYLang(Path archivo, RecolectorErrores errores) throws IOException {
        String nombreArchivo = archivo.toString();
        CharStream entrada = CharStreams.fromPath(archivo);
        YLangLexer lexer = new YLangLexer(entrada);
        lexer.removeErrorListeners();
        lexer.addErrorListener(new EscuchaErrores(errores, TipoError.LEXICO, nombreArchivo));
        YLangParser parser = new YLangParser(new CommonTokenStream(lexer));
        parser.removeErrorListeners();
        parser.addErrorListener(new EscuchaErrores(errores, TipoError.SINTACTICO, nombreArchivo));

        ParseTree arbol = parser.programa();
        if (errores.tieneErrores()) {
            return List.of();
        }

        YLangSemanticoListener semantico = new YLangSemanticoListener(errores, nombreArchivo);
        ParseTreeWalker.DEFAULT.walk(semantico, arbol);
        return semantico.getTabla().getHistorial();
    }
}
